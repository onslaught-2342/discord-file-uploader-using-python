DATABASE_FILE = 'file_data.db'
WEBHOOK_URL = 'https://discord.com/api/webhooks/1223502869337083914/Q3Zs-vonA6gC58KsK5w6Vspc4565Q1WbDO1UxC14gbZgVtQnwDn88D4WdvBnCRHnxtqo'
